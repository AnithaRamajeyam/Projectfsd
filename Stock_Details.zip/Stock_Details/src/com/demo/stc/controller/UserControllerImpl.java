package com.demo.stc.controller;

import com.demo.stc.domain.User;
import com.demo.stc.service.UserService;
import com.demo.stc.service.UserServiceImpl;

public class UserControllerImpl implements UserController {

	UserService service=new UserServiceImpl();

	@Override
	public int registerUser(User user) {
		int result=service.registerUser(user);
		return result;
	}

}

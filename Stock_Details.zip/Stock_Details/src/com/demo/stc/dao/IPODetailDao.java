package com.demo.stc.dao;

import java.util.List;

import com.demo.stc.domain.IPODetail;

public interface IPODetailDao {

	public int insertIPODetail(IPODetail ipodetail);

	public List<IPODetail> getAllIPOPLanned();

}

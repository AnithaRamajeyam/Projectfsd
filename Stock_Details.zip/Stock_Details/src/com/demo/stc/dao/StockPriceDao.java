package com.demo.stc.dao;

public interface StockPriceDao {

}

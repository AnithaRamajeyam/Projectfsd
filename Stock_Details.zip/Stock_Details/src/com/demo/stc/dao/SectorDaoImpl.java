package com.demo.stc.dao;

public class SectorDaoImpl implements SectorDao {

}

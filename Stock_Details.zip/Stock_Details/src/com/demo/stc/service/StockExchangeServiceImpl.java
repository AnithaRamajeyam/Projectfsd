package com.demo.stc.service;

import java.sql.SQLException;
import java.util.List;

import com.demo.stc.dao.StockExchangeDao;
import com.demo.stc.dao.StockExchangeDaoImpl;
import com.demo.stc.domain.StockExchange;

public class StockExchangeServiceImpl implements StockExchangeService {

	StockExchangeDao stockdao;
	@Override
	public int insertStockExchangeDetails(StockExchange stock) throws SQLException {
		stockdao=new StockExchangeDaoImpl();
		int result=stockdao.insertStockExchangeDetails(stock);
		return result;
	}

	@Override
	public List<StockExchange> getAllStockExchangedetails() throws Exception {
		stockdao=new StockExchangeDaoImpl();
		List<StockExchange> list=stockdao.getAllStockExchangedetails();
		return list;
	}

}

package com.demo.stc.service;

import com.demo.stc.dao.UserDao;
import com.demo.stc.dao.UserDaoImpl;
import com.demo.stc.domain.User;

public class UserServiceImpl implements UserService {

	UserDao dao;
	@Override
	public int registerUser(User user) {
		dao=new UserDaoImpl();
		int result=dao.registerUser(user);
		return result;
	}

}

package com.demo.stc.service;

import com.demo.stc.domain.User;

public interface UserService {

	public int registerUser(User user);
}

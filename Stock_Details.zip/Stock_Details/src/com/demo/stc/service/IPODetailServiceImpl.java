package com.demo.stc.service;

import java.sql.SQLException;
import java.util.List;

import com.demo.stc.dao.IPODetailDao;
import com.demo.stc.dao.IPODetailDaoImpl;
import com.demo.stc.domain.IPODetail;

public class IPODetailServiceImpl implements IPODetailService {

	IPODetailDao ipodao;
	@Override
	public int insertIPODetail(IPODetail ipodetail) throws SQLException {
		ipodao = new IPODetailDaoImpl();
		int result=ipodao.insertIPODetail(ipodetail);
		return result;
	}

	@Override
	public List<IPODetail> getAllIPOPLanned() throws Exception {
		ipodao=new IPODetailDaoImpl();
		List<IPODetail> list=ipodao.getAllIPOPLanned();
		return list;
	}

}

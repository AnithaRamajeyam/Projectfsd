package com.demo.stc.service;

public interface SectorService {

}

package com.demo.stc.service;

public class SectorServiceImpl implements SectorService {

}

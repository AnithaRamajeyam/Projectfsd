package com.example.stockspring.model;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


import java.math.BigDecimal;
import java.util.List;

@Entity
@Table(name="company")
public class Company {
	
	@Id
	@Column(name="company_code")
	private int companyId;
	
	@Column(name="board")
	private String boardofdirectors;
	@Column(name="company_name")
	private String companyName;
	
	@Column(name="ceo")
	private String ceoName;
	
	private BigDecimal turnover;
	
	@OneToMany(mappedBy="company")
	private List<Stock> stock;
	
	@Column(name="breifwriteup")
	private String breifWriteUp;
	
	private int stock_code;

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getBoardofdirectors() {
		return boardofdirectors;
	}

	public void setBoardofdirectors(String boardofdirectors) {
		this.boardofdirectors = boardofdirectors;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCeoName() {
		return ceoName;
	}

	public void setCeoName(String ceoName) {
		this.ceoName = ceoName;
	}

	public BigDecimal getTurnover() {
		return turnover;
	}

	public void setTurnover(BigDecimal turnover) {
		this.turnover = turnover;
	}

	public List<Stock> getStock() {
		return stock;
	}

	public void setStock(List<Stock> stock) {
		this.stock = stock;
	}

	public String getBreifWriteUp() {
		return breifWriteUp;
	}

	public void setBreifWriteUp(String breifWriteUp) {
		this.breifWriteUp = breifWriteUp;
	}

	public int getStock_code() {
		return stock_code;
	}

	public void setStock_code(int stock_code) {
		this.stock_code = stock_code;
	}
	
	
	
}
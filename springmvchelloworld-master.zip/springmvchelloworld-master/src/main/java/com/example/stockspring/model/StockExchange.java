package com.example.stockspring.model;

import java.util.Stack;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class StockExchange {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Stockexchangeid;
	
	private String stockExchangeName;
	private String brief;
	private String contactAddress;
	private String remarks;

	@OneToOne(mappedBy="StockExchange")
	private Stock stock;
	
	public Stock getStock() {
		return stock;
	}

	public void setStock(Stock stock) {
		this.stock = stock;
	}

	
	public int getStockexchangeid() {
		return Stockexchangeid;
	}

	public void setStockexchangeid(int stockexchangeid) {
		Stockexchangeid = stockexchangeid;
	}

	public String getStockExchangeName() {
		return stockExchangeName;
	}

	public void setStockExchangeName(String stockExchangeName) {
		this.stockExchangeName = stockExchangeName;
	}

	public String getBrief() {
		return brief;
	}

	public void setBrief(String brief) {
		this.brief = brief;
	}

	public String getContactAddress() {
		return contactAddress;
	}

	public void setContactAddress(String contactAddress) {
		this.contactAddress = contactAddress;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}

package com.example.stockspring.model;

import java.util.*;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="stock_price")
public class Stock {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int stockId;	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="company_code")
	private Company company;
	
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="exchangeid")
	private StockExchange StockExchange;
	
	public StockExchange getStockExchange() {
		return StockExchange;
	}

	public void setStockExchange(StockExchange stockExchange) {
		StockExchange = stockExchange;
	}

	@Column(name="current_price")
	private double currentPrice;
	
	@Column(name="date")
	private Date date;
	
	@Column(name="time")
	private Date time;
	
	
	public int getStockId() {
		return stockId;
	}

	public void setStockId(int stockId) {
		this.stockId = stockId;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}
	
	public double getCurrentPrice() {
		return currentPrice;
	}

	public void setCurrentPrice(double currentPrice) {
		this.currentPrice = currentPrice;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}
}
